autoreconf -ivf &&
help2man ./sipp -N -o sipp.1
