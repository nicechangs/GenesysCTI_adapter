#!/bin/sh
PATH=/bin:/usr/bin
export PATH
rm -r Perl lib cfgutility install_common.pm install_lib.pm ip_description.pm installer.inf perl_user_license_agreement.txt 
rm cleanup.sh
