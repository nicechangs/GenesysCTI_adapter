#!/usr/local/bin/perl

#===============================================================================
#	Genesys Production
#	Copyright (C) 2009 Genesys Telecommunications Laboratories, Inc.
#===============================================================================
#	Description:	Main script for Unix-based installation of IVR SDK product
#
#	History of changes:
#		2009-07-30, version 1.00, AlxNik
#			First release. Created from intersdkappblock.pl, version 1.11.
#===============================================================================

use strict;
use warnings;
use v5.6.1;

use install_common 1.69;
use install_lib 1.95;

#===============================================================================
# Product specific variables
#===============================================================================

my $PRODUCT="To_be_defined_during_run-time";
my $TARFILE="data.tar.gz";
my $ProductVersion="To_be_defined_during_run-time";
my $UseLicense=0;

#===============================================================================
# Additional variables
#===============================================================================
my $TargetDir="";
my $sourcedir="";
my $StartingVersionFor_EULA_Support="7.6.200.00";

#===============================================================================
# Subroutines
#===============================================================================

#===============================================================================
# Initialize 
#===============================================================================

install_lib::Init();

#===============================================================================
# The main section of the script starts here
#===============================================================================

install_lib::UpdateProductData(\$PRODUCT,\$ProductVersion);
install_lib::PrintInstallationHeader($ProductVersion,$PRODUCT);
install_lib::GetOperationMode($StartingVersionFor_EULA_Support,0,1,\$UseLicense);
install_lib::UseEULA();
install_lib::ProcessLicenseAgreement($UseLicense);

# verify target dir
$TargetDir=install_common::PREPTARGET($TargetDir);

# perform data move
install_common::DATAMOVE($TARFILE, $TargetDir);

install_lib::PrintInstallationFooter($PRODUCT);
